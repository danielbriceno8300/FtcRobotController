package org.firstinspires.ftc.teamcode.opmodes;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;

import org.firstinspires.ftc.teamcode.PI_RHO_BASE.PiRhoBaseAuto;


public class duckAutoBlueMidDepo extends PiRhoBaseAuto {

    public void actions() {
        //drive out from the wall
        robot.drive(-6);
        //turn to the left
        robot.turn(90);
        //keeps intake running
        robot.setIntakePower(1);
        //drive towards warehouse
        robot.drive(-20);
        //turn to the right
        robot.turn(0);
        //drive into hub
        robot.drive(-10);
        //stops intake
        robot.setIntakePower(0);
        //raise lift
        robot.setLiftPower(-.70);
        sleep(1000);
        robot.drive(-2);
        //deposits freight
        robot.bucket.setPosition(.6);
        sleep(500);
        //turns
        robot.setLiftPower(.75);
        sleep(250);
        robot.setLiftPower(0);
        //drives back from hub
        robot.drive(12);


    }
}
